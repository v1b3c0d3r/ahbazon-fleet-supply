/*
 * firebase-config.js
 * ---------------------------------------------------------------------------
 * Paste your Firebase project's web config below. Get it from:
 *   Firebase console -> Project settings -> "Your apps" -> SDK setup & config
 *
 * You ONLY need these fields for the Realtime Database to work. The most
 * important one is databaseURL.
 *
 * Until you replace the YOUR_... placeholders, the app falls back to
 * localStorage (works on one device only, no cross-device sync).
 *
 * See SETUP.md for step-by-step instructions (takes ~5 minutes, free).
 */
window.FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
