/*
 * storage.js — compatibility layer for Ahbazon Fleet Supply
 * ---------------------------------------------------------------------------
 * The app pages were written against an async key/value API:
 *
 *     await window.storage.get(key, shared)
 *     await window.storage.set(key, value, shared)
 *     await window.storage.delete(key, shared)
 *     await window.storage.list(prefix, shared)
 *
 * This file re-implements that API for normal web hosting:
 *   - shared === true  -> Firebase Realtime Database  (synced across all users/devices)
 *   - shared === false -> browser localStorage         (private to this browser)
 *
 * Values are strings (the app stores JSON strings), matching the original API.
 * Returns { key, value, shared } | null, same as before.
 *
 * Requires firebase-config.js to define window.FIREBASE_CONFIG before this loads.
 */
(function () {
  "use strict";

  var SHARED_ROOT = "ahbazon"; // top-level node in your Firebase DB
  var db = null;
  var firebaseReady = false;

  // ---- Firebase init (only if a real config is present) -------------------
  function looksConfigured(cfg) {
    return cfg && typeof cfg.databaseURL === "string" &&
           cfg.databaseURL.indexOf("YOUR_") === -1 &&
           cfg.databaseURL.length > 10;
  }

  try {
    var cfg = window.FIREBASE_CONFIG;
    if (looksConfigured(cfg) && window.firebase) {
      firebase.initializeApp(cfg);
      db = firebase.database();
      firebaseReady = true;
    } else {
      console.warn(
        "[storage] Firebase not configured. Shared data will fall back to " +
        "localStorage (this device only). Edit js/firebase-config.js to enable sync."
      );
    }
  } catch (e) {
    console.error("[storage] Firebase init failed:", e);
  }

  // Firebase keys may not contain . $ # [ ] / — encode to be safe.
  function safeKey(k) {
    return encodeURIComponent(String(k)).replace(/\./g, "%2E");
  }

  // ---- localStorage backend (private, and shared-fallback) ----------------
  var local = {
    get: function (key) {
      try {
        var v = window.localStorage.getItem(key);
        return v === null ? null : { key: key, value: v, shared: false };
      } catch (e) { return null; }
    },
    set: function (key, value) {
      try {
        window.localStorage.setItem(key, value);
        return { key: key, value: value, shared: false };
      } catch (e) { return null; }
    },
    del: function (key) {
      try {
        window.localStorage.removeItem(key);
        return { key: key, deleted: true, shared: false };
      } catch (e) { return null; }
    },
    list: function (prefix) {
      var keys = [];
      try {
        for (var i = 0; i < window.localStorage.length; i++) {
          var k = window.localStorage.key(i);
          if (!prefix || k.indexOf(prefix) === 0) keys.push(k);
        }
      } catch (e) {}
      return { keys: keys, prefix: prefix || "", shared: false };
    }
  };

  // ---- Firebase backend (shared) ------------------------------------------
  function fbRef(key) {
    return db.ref(SHARED_ROOT + "/" + safeKey(key));
  }

  var shared = {
    get: function (key) {
      return fbRef(key).once("value").then(function (snap) {
        var v = snap.val();
        return v === null || v === undefined
          ? null
          : { key: key, value: v, shared: true };
      });
    },
    set: function (key, value) {
      return fbRef(key).set(value).then(function () {
        return { key: key, value: value, shared: true };
      });
    },
    del: function (key) {
      return fbRef(key).remove().then(function () {
        return { key: key, deleted: true, shared: true };
      });
    },
    list: function (prefix) {
      return db.ref(SHARED_ROOT).once("value").then(function (snap) {
        var all = snap.val() || {};
        var keys = Object.keys(all).map(function (k) {
          try { return decodeURIComponent(k); } catch (e) { return k; }
        });
        if (prefix) keys = keys.filter(function (k) { return k.indexOf(prefix) === 0; });
        return { keys: keys, prefix: prefix || "", shared: true };
      });
    }
  };

  // ---- Public API: window.storage -----------------------------------------
  window.storage = {
    get: function (key, isShared) {
      if (isShared && firebaseReady) return shared.get(key);
      return Promise.resolve(local.get(key));
    },
    set: function (key, value, isShared) {
      if (isShared && firebaseReady) return shared.set(key, value);
      return Promise.resolve(local.set(key, value));
    },
    delete: function (key, isShared) {
      if (isShared && firebaseReady) return shared.del(key);
      return Promise.resolve(local.del(key));
    },
    list: function (prefix, isShared) {
      if (isShared && firebaseReady) return shared.list(prefix);
      return Promise.resolve(local.list(prefix));
    }
  };

  // Expose a flag pages can check if they want to warn the user.
  window.STORAGE_BACKEND = firebaseReady ? "firebase" : "localStorage";
})();
