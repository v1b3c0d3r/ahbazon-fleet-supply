# Ahbazon Fleet Supply

A lightweight ship-ordering and contract-tracking web app for an EVE Online
NPSI community operating out of Ahbazon. Two pages, one shared order list:

| Page | File | Who uses it |
|------|------|-------------|
| **Player Order Form** | `order.html` | Fleet members — build and submit a ship order under their character name |
| **Order Tracker** | `index.html` | You / logistics staff — see incoming orders, track shipping stages, mark contracts filled, and keep a completed-contracts log |

Orders submitted on the form appear automatically on the tracker. Each order
can be advanced through shipping stages (Queued → Sourcing → In Transit →
Staged @ Ahbazon), marked filled (which logs it and clears it from the board),
or cancelled.

> ⚠️ **Share the right links.** Give members the **`order.html`** link only.
> Anyone with the **`index.html`** (tracker) link has full management control
> over every order. There is no login layer.

## Hosting

This is a static site (just HTML/CSS/JS) and can be hosted free on
**GitHub Pages**, Netlify, Cloudflare Pages, or any static host.

For orders to sync across devices (players on their machines → your tracker),
the app uses **Firebase Realtime Database** (free tier is plenty). Setup takes
about 5 minutes — see **[SETUP.md](SETUP.md)**.

Until Firebase is configured, the app still runs but falls back to
`localStorage`, meaning data is per-browser and does **not** sync between the
form and the tracker on different devices.

## Quick start

1. Create a free Firebase project and Realtime Database (see `SETUP.md`).
2. Paste your config into `js/firebase-config.js`.
3. Commit and push to a GitHub repo.
4. Enable **GitHub Pages** (Settings → Pages → deploy from `main`, root).
5. Your tracker is at `https://<user>.github.io/<repo>/` and the player form is
   at `https://<user>.github.io/<repo>/order.html`.

## The doctrine

Ship codes, names, and prices are defined in the `SHIPS` array near the top of
the inline `<script>` in **both** `index.html` and `order.html`. To change
pricing or hulls, edit the array in both files so they stay in sync. Prices are
in millions of ISK; the UI rolls values ≥ 1,000m into billions (e.g. `2.17b`).

## Files

```
ahbazon-fleet-supply/
├── index.html            # Order tracker (admin)
├── order.html            # Player order form
├── js/
│   ├── storage.js        # Firebase/localStorage compatibility layer
│   └── firebase-config.js# Your Firebase keys (you fill this in)
├── database.rules.json   # Suggested Firebase security rules
├── SETUP.md              # Step-by-step Firebase + GitHub Pages guide
├── LICENSE
└── README.md
```

## Notes

- Character names are self-reported (no in-game verification). Match the typed
  name when creating contracts.
- The completed-contracts log lives privately in the tracker browser
  (`localStorage`), separate from the shared order pool.
- Timestamps use the tracker device's local time.
