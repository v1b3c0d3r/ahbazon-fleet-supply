# Setup Guide

This walks you through getting the app live and syncing across devices. Two
parts: **Firebase** (the shared database) and **GitHub Pages** (the hosting).
Total time ~10 minutes. Everything used here is free.

---

## Part 1 — Firebase Realtime Database (cross-device sync)

1. Go to <https://console.firebase.google.com/> and sign in with a Google
   account.
2. Click **Add project** (or **Create a project**). Give it a name like
   `ahbazon-fleet`. You can disable Google Analytics — it's not needed.
3. When the project is ready, in the left sidebar open
   **Build → Realtime Database**.
4. Click **Create Database**.
   - Pick a location close to your members.
   - When asked about security rules, choose **Start in test mode** for now
     (we'll lock it down in step 7).
5. Register a web app: click the gear icon → **Project settings** → scroll to
   **Your apps** → click the **`</>`** (Web) icon. Give it a nickname, click
   **Register app**. You do **not** need Firebase Hosting.
6. Firebase shows you a `firebaseConfig` object. Copy those values into
   **`js/firebase-config.js`** in this project, replacing the `YOUR_...`
   placeholders. The critical field is **`databaseURL`** — make sure it's
   present (it looks like
   `https://your-project-default-rtdb.firebaseio.com`). If it's missing from
   the snippet, copy it from the Realtime Database page.
7. **Lock down the rules.** In **Realtime Database → Rules**, replace the
   contents with the rules from **`database.rules.json`** in this repo (also
   shown below), then click **Publish**. This keeps the data scoped to this
   app's node.

   ```json
   {
     "rules": {
       "ahbazon": {
         ".read": true,
         ".write": true
       }
     }
   }
   ```

   > These rules allow anyone who has your site to read and write the order
   > list. That's appropriate for a community tool where members submit orders
   > without accounts. It does mean the data isn't secret — don't store
   > anything sensitive. If you later want tighter control, Firebase supports
   > Anonymous Auth and per-path rules; see the note at the end.

That's it for Firebase. If `firebase-config.js` is filled in correctly, the
form and tracker now share one live order list across every device.

---

## Part 2 — Host on GitHub Pages

1. Create a new repository on GitHub (e.g. `ahbazon-fleet-supply`). It can be
   public or private; Pages works with both on free accounts.
2. Upload all the files in this folder (keep the `js/` folder structure
   intact). You can drag-and-drop them in the GitHub web UI via
   **Add file → Upload files**, or use `git`:

   ```bash
   git init
   git add .
   git commit -m "Ahbazon Fleet Supply"
   git branch -M main
   git remote add origin https://github.com/<you>/ahbazon-fleet-supply.git
   git push -u origin main
   ```

3. In the repo, go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to *Deploy from a branch*,
   choose **`main`** branch and **`/ (root)`**, then **Save**.
5. Wait ~1 minute. GitHub gives you a URL like
   `https://<you>.github.io/ahbazon-fleet-supply/`.

### Your links

- **Tracker (keep private):** `https://<you>.github.io/ahbazon-fleet-supply/`
- **Player form (share this):**
  `https://<you>.github.io/ahbazon-fleet-supply/order.html`

---

## Verifying it works

1. Open the **player form**, submit a test order under a fake name.
2. Open the **tracker** on a *different* device or browser. The test order
   should appear within a few seconds (the tracker polls every 5s).
3. Mark it filled on the tracker — it moves to the Completed Contracts Log.

If orders don't sync between devices, open the browser console (F12) on each
page. A message like `[storage] Firebase not configured` means
`firebase-config.js` still has placeholders or a bad `databaseURL`.

---

## Optional: tighter security later

The test rules above are open read/write on the `ahbazon` node. If you want to
prevent random people from wiping data, the common upgrade is:

- Turn on **Anonymous Authentication** (Firebase → Build → Authentication →
  Sign-in method → Anonymous → Enable).
- Change the rules to require an authenticated session:

  ```json
  {
    "rules": {
      "ahbazon": {
        ".read": "auth != null",
        ".write": "auth != null"
      }
    }
  }
  ```

This still lets anyone using your site read/write (they get an anonymous
session automatically), but blocks unauthenticated API calls from outside.
Implementing anonymous sign-in requires a few extra lines in `storage.js`;
ask if you want that wired up.
